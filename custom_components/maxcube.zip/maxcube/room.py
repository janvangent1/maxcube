class MaxRoom(object):
    def __init__(self):
        self.id = None
        self.name = None
